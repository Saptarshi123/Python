class Course:
    courseName=""

    def getCourseName(self):
        return self.courseName

    def setCourseName(self,courseName):
        self.courseName=courseName

    def __repr__(self):
        return self.courseName

