class InvalidAccountNumberException(Exception):
    pass

class LowBalanceException(Exception):
    pass