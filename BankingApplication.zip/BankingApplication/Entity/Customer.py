class Customer:

    def getName(self):
        return self.name

    def setName(self,name):
        self.name=name

    def getAge(self):
        return self.age

    def setAge(self,age):
        self.age=age;

    def setContactNumber(self,contactNumber):
        self.contactNumber=contactNumber

    def getContactNumber(self):
        return self.contactNumber;