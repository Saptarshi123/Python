class Account:

    def setAccountNumber(self,accountNumber):
        self.accountNumber=accountNumber

    def getAccountNumber(self):
        return self.accountNumber

    def setBalance(self,balance):
        self.balance=balance

    def getBalance(self):
        return self.balance

    def getCustomer(self):
        return self.customer

    def setCustomer(self,customer):
        self.customer=customer

